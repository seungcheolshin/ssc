from pico2d import *

import Bullet

def handle_events():
    global running
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            running = False
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            running = False

open_canvas()

running = True
i = 4
bullets = [Bullet.Basic() for i in range(11)]

while running:
    clear_canvas()

    for bullet in bullets:
        bullet.update(i*100,300)
        i = (i + 1) % 8

    for bullet in bullets:
        bullet.draw(50,0)

    update_canvas()
    delay(0.05)
    handle_events()

close_canvas()