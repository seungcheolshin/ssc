from pico2d import *
import Background
import Character
import UI
import Bullet
import Enemy
import Item

program = None
bg_01 = None
ui = None
SHOP = False
arrow = None
char_body, char_leg = None,None
key = None
body_state = None
leg_state = None
direction = None
bullets = None
bombs = None
enemy_basic = None
shooting = 0
bullet_count = 0
bomb_count = 0
current_time = 0.0
frame_time = 0.0
sy = 0.0
E_B_state = 0
items = None

LEFT,RIGHT, UP = 0,1,2
GOLD, BOX, FISH = 0,1,2

# CHAR_BODY
# STAND, RUN, JUMP, SHOT, STAB, SWING, BOMB = 0,1,2,3,4,5,6

# CHAR_LEG
# STAND, RUN, JUMP, MOVE = 0,1,2,3

STAND, RUN, SHOT, JUMP, STAB, SWING, BOMB = 0,1,2,3,4,5, 7
MOVEJUMP = 6

PIXEL_PER_METER = (10.0 / 0.3)  # 10 pixel 30 cm
RUN_SPEED_KMPH = 20.0
RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60)
RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

TIME_PER_ACTION = 0.5
ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
FRAMES_PER_ACTION = 8


def enter():
    global program
    global bg_01
    global ui
    global char_body, char_leg
    global key
    global arrow
    global body_state, leg_state
    global direction
    global bullets
    global shooting
    global enemy_basics
    global items
    global bombs

    shooting = 50
    direction = RIGHT
    body_state = STAND
    leg_state = STAND
    program = True
    bg_01 = Background.BG()
    ui = UI.Life_Money_Shop()
    arrow = UI.Arrow()
    char_body = Character.Character_body()
    char_leg = Character.Character_leg()
    enemy_basics = [Enemy.Enemy_Basic() for i in range(20)]
    bullets = [Bullet.Basic() for i in range(20)]
    bombs = [Bullet.Bomb() for i in range(20)]
    for bullet in bullets:
        bullet.y = -50
    for bomb in bombs:
        bomb.y = -50
    items = [Item.Item() for i in range(10)]

def update():
    global body_state
    global bullets, bombs
    global bullet_count, bomb_count
    global enemy_basics
    global E_B_state
    global ui
    global items

    for enemy_basic in enemy_basics:
        if collision(char_body, enemy_basic):
            if (char_body.state == STAB or  char_body.state == SWING) and enemy_basic.state == 1:
                enemy_basic.state = 2

            if enemy_basic.state == 1:
                if enemy_basic.frame == 8:
                    ui.life -=1
            elif enemy_basic.state == 0:
                print("충돌")
                enemy_basic.state = 1


    for i in range(20):
        for j in range(20):
            if collision(bullets[i], enemy_basics[j]):
                print("충돌")
                bullets[i].y = -100
                enemy_basics[j].state = 2

        for item in items:
            for bullet in bullets:
                if(item.state == BOX):
                    if collision(bullet,item):
                        print("충돌")
                        bullet.y = -100
                        item.box = 1
                    if char_body.state == SWING or char_body.state == STAB:
                        if collision(char_body,item):
                            print("충돌")
                            bullet.y = -100
                            item.box = 1
                else:
                    if collision(char_body,item):
                        print("충돌")
                        if item.state == 0:
                            ui.money+=1
                        if item.state == 2:
                            ui.life+=1

                        item.state = 3





    if arrow.frame < 16:
        arrow.update()
    if char_body.shot == 9 or char_body.stab == 5 or char_body.swing == 5 or char_body.bomb == 5:
        body_state = STAND
        char_body.shot = 0
        char_body.stab = 0
        char_body.swing = 0
        char_body.bomb = 0

    for i in range(20):
        bullets[i].update()

    for bomb in bombs:
        bomb.update()

    char_body.move(key,direction,body_state)
    char_leg.move(key,direction,leg_state)
    if char_body.x > 380 and key == RIGHT:
        bg_01.x +=3
        for enemy_basic in enemy_basics:
            enemy_basic.x -=3
        for item in items:
            item.x -=6



    char_body.update()
    char_leg.update()

    for enemy_basic in enemy_basics:
        enemy_basic.update()

    for item in items:
        item.update()





def draw():
    global bullet_count
    global bomb_count


    clear_canvas()


    bg_01.draw()
    ui.draw()
    arrow.draw()
    char_leg.draw()
    char_body.draw()

    for enemy_basic in enemy_basics:
        enemy_basic.draw()

    for item in items:
        item.draw()


    for i in range(20):
        bullets[i].draw(direction)

    for bomb in bombs:
        bomb.draw(direction)








def exit():
    global bg_01,ui,arrow,char_body,char_leg, bullets, items
    global bombs, enemy_basic

    del(enemy_basic)
    del(bombs)
    del(bg_01)
    del(ui)
    del(arrow)
    del(char_body)
    del(char_leg)
    del(bullets)
    del(items)

def get_frame_time():

    global current_time

    frame_time = get_time() - current_time
    current_time += frame_time
    return frame_time


def handle_events():

     global program
     global key
     global body_state,leg_state
     global direction
     global SHOP
     global bullet_count, bomb_count
     mx,my = 0,0

     events = get_events()

     for event in events:
        if event.type == SDL_QUIT:
               program = False
        elif event.type == SDL_MOUSEBUTTONDOWN:
            if event.button == SDL_BUTTON_LEFT:
                mx, my = event.x, 768 - event.y
                if mx > 945 and mx < 1015 and my >685 and my < 755:
                    SHOP = True;


        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_RIGHT:
                key = RIGHT
                direction = RIGHT
                body_state, leg_state = RUN,RUN
            elif event.key == SDLK_LEFT:
                key = LEFT
                direction = LEFT
                body_state, leg_state = RUN,RUN
            elif event.key == SDLK_UP:
                body_state,leg_state = JUMP, JUMP
                key = UP
            elif event.key == SDLK_s:
                body_state = SHOT
                bullets[bullet_count].insert(char_body.x, char_body.y)
                bullet_count = (bullet_count + 1) % 20
            elif event.key == SDLK_a:
                body_state = STAB
            elif event.key == SDLK_d:
                body_state = SWING
            elif event.key == SDLK_q:
                body_state = BOMB
                bombs[bomb_count].insert(char_body.x, char_body.y)
                bomb_count = (bomb_count + 1) % 20


            elif event.key == SDLK_ESCAPE:
                    program = False


        elif event.type == SDL_KEYUP:
            if event.key == SDLK_RIGHT:
                key = -1
                leg_state = STAND
            elif event.key == SDLK_LEFT:
                key = -1
                leg_state = STAND



def collision(a, b):
    left_a, bottom_a, right_a, top_a = a.get_bb()
    left_b, bottom_b, right_b, top_b = b.get_bb()

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a < bottom_b: return False
    if bottom_a > top_b: return False

    return True


def main():
    global current_time, frame_time

    current_time = get_time()
    frame_time = get_frame_time()
    open_canvas(1024, 768)
    enter()
    while program:
        handle_events()
        update()
        draw()
        update_canvas()
        delay(0.03)

    exit()
    close_canvas()

if __name__ == '__main__':
    main()

