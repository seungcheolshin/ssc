from pico2d import *
import random

class Enemy_Basic():
    def __init__(self):
        self.image = load_image('Enemy_basic.png')
        self.x, self.y = random.randint(800,2800), 140
        self.frame = 0
        self.state = 0

    def update(self):
        if self.state == 2:
            self.x +=2
            self.y -=2
            if(self.frame < 10):
                self.frame += 1
        else:
            self.x -= 3
            self.frame = (self.frame + 1) % 10


    def draw(self):
        self.image.clip_draw(self.frame * 56, 50 * self.state, 56, 50, self.x, self.y , 120,120)
        #draw_rectangle(*self.get_bb())



    def get_bb(self):
        if self.state == 2:
            return 0,0,0,0
        return self.x - 120 + (60 * self.state), self.y - 60, self.x, self.y + 60
