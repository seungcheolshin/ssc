from pico2d import *
import random

class Item():
    def __init__(self):
        self.image = load_image('Item_type.png')
        self.x, self.y = random.randint(800,2800), 140
        self.frame = 0
        self.state = 1
        self.box = 0

    def update(self):
        if(self.box == 1):
            self.frame = (self.frame + 1)
            if( self.frame == 10):
                while(self.state == 1):
                    self.state = random.randint(0,2)
                self.frame = 0
        elif(self.frame != 1):
            self.frame = (self.frame + 1) % 10



    def draw(self):
        self.image.clip_draw(50*self.frame, 50 * self.state, 50, 50, self.x, self.y , 150,150)
        draw_rectangle(*self.get_bb())


    def get_bb(self):
        if(self.box == 0):
            return self.x - 50,self.y - 50, self.x + 30, self.y + 50
        if(self.state == 3):
            return 0,0,0,0
        return self.x -70, self.y-60, self.x - 40, self.y - 30
