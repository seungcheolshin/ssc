from pico2d import*

LEFT, RIGHT = 0,1
Shooting = 30

class Basic:
    def __init__(self):
        self.x, self.y = 0,0
        self.image = load_image('bullet_basic.png')

    def insert(self, char_x, char_y):
        self.x = char_x + 30
        self.y = char_y

    def update(self):
        self.x += Shooting


    def draw(self, direction):
        if direction == RIGHT:
            self.image.draw(self.x ,self.y)
        if direction == LEFT:
            self.image.draw(-self.x - 50 ,self.y)

    def get_bb(self):
        return self.x, self.y, self.x, self.y

class Bomb:
    def __init__(self):
        self.x, self.y, self.frame = 0,0, 0
        self.image = load_image('bullet_bomb.png')

    def insert(self, char_x, char_y):
        self.x = char_x + 30
        self.y = char_y + 30

    def update(self):
        if self.y > 0:
            self.x += 15
            self.y -=5
            self. frame = self.frame+1


    def draw(self, direction):
        if direction == RIGHT:
            self.image.clip_draw(20 * self.frame, 0, 20, 25, self.x, self.y, 50, 50)
        if direction == LEFT:
            self.image.draw(-self.x - 50 ,self.y)

    def get_bb(self):
        return self.x, self.y, self.x, self.y