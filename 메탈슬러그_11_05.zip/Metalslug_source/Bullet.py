from pico2d import*

LEFT, RIGHT = 0,1

class Basic:
    def __init__(self):
        self.x, self.y = 0,0
        self.image = load_image('bullet_basic.png')

    def update(self, char_x, char_y):
        self.x , self.y = char_x + 50, char_y
    def draw(self, shooting, direction):
        if direction == RIGHT:
            self.image.draw(self.x + shooting ,self.y)
        if direction == LEFT:
            self.image.draw(self.x + shooting - 50 ,self.y)