from pico2d import *
import Background
import Character
import UI
import Bullet

program = None
bg_01 = None
ui = None
SHOP = False
arrow = None
char_body, char_leg = None,None
key = None
body_state = None
leg_state = None
direction = None
bullets = None
shooting = 0
bullet_count = 0

LEFT,RIGHT, UP = 0,1,2
# CHAR_BODY
# STAND, RUN, JUMP, SHOT, STAB, SWING, BOMB = 0,1,2,3,4,5,6
# CHAR_LEG
# STAND, RUN, JUMP, MOVE = 0,1,2,3
STAND, RUN, SHOT, JUMP, STAB, SWING = 0,1,2,3,4,5
MOVEJUMP = 6

def enter():
    global program
    global bg_01
    global ui
    global char_body, char_leg
    global key
    global arrow
    global body_state, leg_state
    global direction
    global bullets
    global shooting

    shooting = 50
    direction = RIGHT
    body_state = STAND
    leg_state = STAND
    program = True
    bg_01 = Background.BG()
    ui = UI.Life_Money_Shop()
    arrow = UI.Arrow()
    char_body = Character.Character_body()
    char_leg = Character.Character_leg()
    bullets = [Bullet.Basic() for i in range(20)]
def update():
    global body_state
    global bullets
    global bullet_count

    if arrow.frame < 16:
        arrow.update()
    if char_body.shot == 9 or char_body.stab == 5 or char_body.swing == 5:
        body_state = STAND
        char_body.shot = 0
        char_body.stab = 0
        char_body.swing = 0

    for i in range(20):
        bullets[i].update()


    char_body.move(key,direction,body_state)
    char_leg.move(key,direction,leg_state)
    if char_body.x > 380 and key == RIGHT:
        bg_01.x +=3

    char_body.update()
    char_leg.update()



def draw():
    global bullet_count

    clear_canvas()
    bg_01.draw()
    ui.draw()
    arrow.draw()
    char_leg.draw()
    char_body.draw()
    for i in range(20):
        bullets[i].draw(direction)



def exit():
    global bg_01,ui,arrow,char_body,char_leg, bullets

    del(bg_01)
    del(ui)
    del(arrow)
    del(char_body)
    del(char_leg)
    del(bullets)


def handle_events():

     global program
     global key
     global body_state,leg_state
     global direction
     global SHOP
     global bullet_count
     mx,my = 0,0

     events = get_events()

     for event in events:
        if event.type == SDL_QUIT:
               program = False
        elif event.type == SDL_MOUSEBUTTONDOWN:
            if event.button == SDL_BUTTON_LEFT:
                mx, my = event.x, 768 - event.y
                if mx > 945 and mx < 1015 and my >685 and my < 755:
                    SHOP = True;


        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_RIGHT:
                key = RIGHT
                direction = RIGHT
                body_state, leg_state = RUN,RUN
            elif event.key == SDLK_LEFT:
                key = LEFT
                direction = LEFT
                body_state, leg_state = RUN,RUN
            elif event.key == SDLK_UP:
                body_state,leg_state = JUMP, JUMP
                key = UP
            elif event.key == SDLK_s:
                body_state = SHOT
                bullets[bullet_count].insert(char_body.x, char_body.y)
                print(bullet_count)
                bullet_count = (bullet_count + 1) % 20
            elif event.key == SDLK_a:
                body_state = STAB
            elif event.key == SDLK_d:
                body_state = SWING


            elif event.key == SDLK_ESCAPE:
                    program = False


        elif event.type == SDL_KEYUP:
            if event.key == SDLK_RIGHT:
                key = -1
                leg_state = STAND
            elif event.key == SDLK_LEFT:
                key = -1
                leg_state = STAND




def main():

    open_canvas(1024, 768)
    enter()
    while program:
        handle_events()
        update()
        draw()
        update_canvas()
        delay(0.05)

    exit()
    close_canvas()

if __name__ == '__main__':
    main()

