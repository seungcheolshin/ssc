from pico2d import *

import Bullet

running = True
shot = None
count = 0
bullets =  None


def handle_events():
    global running, shot
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            running = False
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            running = False
        elif event.type == SDL_KEYDOWN and event.key == SDLK_SPACE:
            shot = True
            bullets[count].insert(30,50)


bullets = [Bullet.Basic() for i in range(10)]

open_canvas()


while running:
    clear_canvas()

    for bullet in bullets:
        bullet.update()

    bullet.draw(0,0)
    update_canvas()
    delay(0.1)
    handle_events()

close_canvas()