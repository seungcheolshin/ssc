from pico2d import *
import random


class Enemy_Basic():
    SIZE = 120
    def __init__(self):
        self.image = load_image('Enemy_basic.png')
        self.x, self.y, self.size = 1200, 0, 0
        self.frame = 0
        self.state = 0

    def create(self):
        self.x, self.y, self.size = 1200,140,self.SIZE

    def update(self):

        if self.size == self.SIZE:
            if self.state == 0:
                self.x -= 3
                self.frame = (self.frame + 1) % 10
            elif self.state == 1:
                self.x -=2
                self.frame = (self.frame + 1) % 10
            else:
                if(self.frame < 10):
                    self.frame += 1


    def draw(self):
        self.image.clip_draw(self.frame * 56, 50 * self.state, 56, 50, self.x, self.y , self.size, self.size)
        if self.state == 1:
            draw_rectangle(*self.get_bb())
        draw_rectangle(*self.get_bb_enemy())


    def get_bb(self):
        if self.state == 2:
            return 0,0,0,0
        return self.x - self.size + (self.size/4 * self.state), self.y - self.size/2, self.x, self.y + self.size/2

    def get_bb_enemy(self):
        if self.state == 2:
            return 0, 0, 0, 0
        return self.x - self.size/2 + (self.size/2 * self.state), self.y - self.size/2, self.x, self.y + self.size/2