from pico2d import*

Life, Money, Shop = 0,1,2

class Life_Money_Shop:
    def __init__(self):
        self.image = load_image("Life_Money_Shop.png")
    def draw(self):
        for i in range(0,5,1):
            self.image.clip_draw(Life*100, 0, 100, 100, 50+(i*55), 730, 50,50 )
        self.image.clip_draw(Money*100, 0, 100, 100, 50, 670, 50,50 )
        self.image.clip_draw(Shop*100, 0, 100, 100, 980, 720,70,70 )

class Arrow:
    def __init__(self):
        self.image = load_image("Arrow_01.png")
        self.frame = 0
    def update(self):
        self.frame = (self.frame+1)

    def draw(self):
        self.image.clip_draw(self.frame * 33, 0, 33, 31, 70, 200)